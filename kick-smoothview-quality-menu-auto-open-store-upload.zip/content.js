(function () {
  const DEFAULTS = {
    mode: "reduce",
    hideEmotes: true,
    hideImages: true,
    disableAnimations: true,
    maxChatNodes: 120,
    preferredQuality: "none",
    qualityEngine: "ui-precise",
    lang: "ar",
    debug: false
  };

  const state = {
    config: { ...DEFAULTS },
    trimObserver: null,
    trimInterval: null,
    qualityInterval: null,
    qualityObserver: null,
    qualityBusy: false,
    qualityDone: false,
    qualityAttempts: 0,
    lastStats: {}
  };

  function setPageDebug(patch) {
    state.lastStats = Object.assign({}, state.lastStats, patch, {
      timestamp: new Date().toISOString(),
      extensionLoaded: true,
      version: "3.0.3"
    });

    try {
      let el = document.getElementById("__kickSmoothViewQualityStats");
      if (!el) {
        el = document.createElement("div");
        el.id = "__kickSmoothViewQualityStats";
        el.style.display = "none";
        (document.documentElement || document.body).appendChild(el);
      }

      el.textContent = JSON.stringify(state.lastStats, null, 2);
      document.documentElement.setAttribute(
        "data-kick-smoothview-quality-stats",
        JSON.stringify(state.lastStats)
      );
    } catch (e) {}
  }

  function loadConfig(cb) {
    chrome.storage.local.get(DEFAULTS, (config) => {
      state.config = Object.assign({}, DEFAULTS, config);
      cb(state.config);
    });
  }

  function inject(config) {
    try {
      const s = document.createElement("script");
      s.src = chrome.runtime.getURL("inject.js");
      s.dataset.kickSmoothViewConfig = JSON.stringify(config);
      (document.documentElement || document.head || document.body).appendChild(s);
      s.remove();
    } catch (e) {
      console.warn("[Kick SmoothView] Injection failed:", e);
    }
  }

  function broadcastConfig() {
    try {
      window.dispatchEvent(new CustomEvent("KickSmoothViewConfig", { detail: state.config }));
    } catch (e) {}
  }

  function applyCss() {
    const old = document.getElementById("kick-smoothview-style");
    if (old) old.remove();

    if (state.config.mode === "off") return;

    let css = "";

    if (state.config.disableAnimations) {
      css += `
        * {
          animation-duration: 0.001s !important;
          animation-iteration-count: 1 !important;
          transition-duration: 0.001s !important;
          scroll-behavior: auto !important;
        }
      `;
    }

    if (state.config.hideEmotes || state.config.hideImages) {
      css += `
        [class*="chat" i] img,
        [data-testid*="chat" i] img,
        aside img,
        [class*="emote" i],
        [class*="emoji" i],
        [alt*="emote" i] {
          display: none !important;
          visibility: hidden !important;
          width: 0 !important;
          height: 0 !important;
        }
      `;
    }

    css += `
      [class*="chat" i],
      [data-testid*="chat" i],
      aside {
        contain: layout paint style !important;
      }
    `;

    const style = document.createElement("style");
    style.id = "kick-smoothview-style";
    style.textContent = css;
    document.documentElement.appendChild(style);
  }

  function isLikelyChatContainer(el) {
    if (!el || !el.nodeType || el.nodeType !== 1) return false;
    const combined = ((el.className || "") + " " + (el.id || "") + " " + (el.getAttribute("data-testid") || "")).toLowerCase();
    return combined.includes("chat");
  }

  function stopChatTrimmer() {
    if (state.trimObserver) state.trimObserver.disconnect();
    state.trimObserver = null;
    if (state.trimInterval) clearInterval(state.trimInterval);
    state.trimInterval = null;
  }

  function startChatTrimmer() {
    stopChatTrimmer();

    if (state.config.mode === "off") return;

    let limit = Number(state.config.maxChatNodes || 120);
    if (state.config.mode === "aggressive") limit = Math.min(limit, 80);
    if (limit <= 0) return;

    function trim(container) {
      const children = Array.from(container.children || []);
      if (children.length > limit) {
        const removeCount = children.length - limit;
        for (let i = 0; i < removeCount; i++) children[i].remove();
      }
    }

    state.trimObserver = new MutationObserver((mutations) => {
      const seen = new Set();
      for (const m of mutations) {
        let node = m.target;
        while (node && node !== document.body) {
          if (isLikelyChatContainer(node) && !seen.has(node)) {
            seen.add(node);
            trim(node);
            break;
          }
          node = node.parentElement;
        }
      }
    });

    function start() {
      state.trimObserver.observe(document.body || document.documentElement, { childList: true, subtree: true });
      state.trimInterval = setInterval(() => {
        document.querySelectorAll('[class*="chat" i], [data-testid*="chat" i], aside').forEach(trim);
      }, 2500);
    }

    if (document.body) start();
    else document.addEventListener("DOMContentLoaded", start, { once: true });
  }

  function resetPlaybackRate() {
    try {
      document.querySelectorAll("video").forEach(v => {
        if (v.playbackRate !== 1) v.playbackRate = 1;
      });
    } catch (e) {}
  }

  function isVisible(el) {
    if (!el || !(el instanceof Element)) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.visibility !== "hidden" &&
      style.display !== "none" &&
      rect.width > 0 &&
      rect.height > 0 &&
      rect.bottom > 0 &&
      rect.right > 0;
  }

  function rectInfo(el) {
    const r = el.getBoundingClientRect();
    return {
      left: Math.round(r.left),
      top: Math.round(r.top),
      width: Math.round(r.width),
      height: Math.round(r.height),
      area: Math.round(r.width * r.height)
    };
  }

  function textOf(el) {
    if (!el) return "";
    return ((el.innerText || el.textContent || "") + " " +
      (el.getAttribute?.("aria-label") || "") + " " +
      (el.getAttribute?.("title") || "") + " " +
      (el.getAttribute?.("data-testid") || "")
    ).replace(/\s+/g, " ").trim().toLowerCase();
  }

  function deepElements(root = document) {
    const out = [];
    function walk(node) {
      if (!node) return;
      try {
        const all = node.querySelectorAll ? Array.from(node.querySelectorAll("*")) : [];
        out.push(...all);
        for (const el of all) {
          if (el.shadowRoot) walk(el.shadowRoot);
        }
      } catch (e) {}
    }
    walk(root);
    return out;
  }

  function clickable(el) {
    if (!el) return null;
    const c = el.closest?.("button,[role='button'],[role='menuitem'],li,a") || el;
    // Avoid returning a massive page wrapper. If the clickable ancestor is huge, use the exact small element.
    try {
      const r = c.getBoundingClientRect();
      if (r.width * r.height > 50000 && el !== c) return el;
    } catch (e) {}
    return c;
  }

  function getMainVideo() {
    const videos = Array.from(document.querySelectorAll("video")).filter(isVisible);
    if (!videos.length) return document.querySelector("video");
    return videos.sort((a, b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();
      return (br.width * br.height) - (ar.width * ar.height);
    })[0];
  }

  function clickEl(el, label) {
    if (!el) return false;
    const target = clickable(el);
    if (!target) return false;

    try {
      target.scrollIntoView({ block: "center", inline: "center" });
    } catch (e) {}

    try {
      const rect = target.getBoundingClientRect();
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;

      ["pointerover", "pointerenter", "mouseover", "mouseenter", "pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach(type => {
        target.dispatchEvent(new MouseEvent(type, {
          bubbles: true,
          cancelable: true,
          view: window,
          clientX: x,
          clientY: y
        }));
      });

      target.click?.();
      setPageDebug({
        lastClick: label || "unknown",
        clickedText: textOf(target).slice(0, 300),
        clickedRect: rectInfo(target),
        clickedTag: target.tagName
      });
      return true;
    } catch (e) {
      try {
        target.click?.();
        setPageDebug({
          lastClick: label || "unknown-fallback",
          clickedText: textOf(target).slice(0, 300),
          clickedRect: rectInfo(target),
          clickedTag: target.tagName
        });
        return true;
      } catch (x) {}
    }

    return false;
  }

  function revealPlayerControls() {
    const video = getMainVideo();
    const target = video || document.body;
    if (!target) return;

    const rect = target.getBoundingClientRect ? target.getBoundingClientRect() : { left: 100, top: 100, width: 500, height: 300 };
    const points = [
      [rect.left + rect.width / 2, rect.top + rect.height / 2],
      [rect.left + rect.width * 0.85, rect.top + rect.height * 0.85],
      [rect.left + rect.width * 0.95, rect.top + rect.height * 0.90]
    ];

    for (const [x, y] of points) {
      ["mousemove", "pointermove", "mouseover"].forEach(type => {
        target.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y }));
        document.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y }));
      });
    }
  }

  function findSmallTextElementExact(patterns) {
    const all = deepElements().filter(isVisible);
    const candidates = [];

    for (const el of all) {
      const t = textOf(el);
      if (!t) continue;

      const ok = patterns.some(p => p.test(t));
      if (!ok) continue;

      const r = el.getBoundingClientRect();
      const area = r.width * r.height;

      // Reject giant containers; they were the bug.
      if (area > 50000) continue;
      if (r.width > 600 || r.height > 200) continue;

      candidates.push({ el, text: t, area, rect: rectInfo(el) });
    }

    candidates.sort((a, b) => a.area - b.area);

    setPageDebug({
      preciseCandidates: candidates.slice(0, 10).map(c => ({
        text: c.text.slice(0, 120),
        rect: c.rect
      }))
    });

    return candidates[0]?.el || null;
  }


  function clickAtPoint(x, y, label) {
    const el = document.elementFromPoint(x, y);
    if (!el) {
      setPageDebug({ lastPointClick: label, pointClickResult: "no-element", x: Math.round(x), y: Math.round(y) });
      return false;
    }

    try {
      ["pointerover", "pointerenter", "mouseover", "mouseenter", "pointermove", "mousemove", "pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach(type => {
        el.dispatchEvent(new MouseEvent(type, {
          bubbles: true,
          cancelable: true,
          view: window,
          clientX: x,
          clientY: y
        }));
      });

      el.click?.();

      setPageDebug({
        lastPointClick: label,
        pointClickResult: "clicked",
        pointClickedText: textOf(el).slice(0, 120),
        pointClickedTag: el.tagName,
        x: Math.round(x),
        y: Math.round(y)
      });

      return true;
    } catch (e) {
      setPageDebug({ lastPointClick: label, pointClickResult: "error", pointClickError: String(e) });
      return false;
    }
  }

  function clickLikelySettingsByCoordinates() {
    const video = getMainVideo();
    if (!video) {
      setPageDebug({ coordinateSettingsClick: "no-video" });
      return false;
    }

    const r = video.getBoundingClientRect();

    // Kick player controls are usually at the bottom right.
    // Try multiple points from right to left so it can catch settings even if fullscreen/theater layout differs.
    const points = [
      [r.left + r.width - 44, r.top + r.height - 42],
      [r.left + r.width - 72, r.top + r.height - 42],
      [r.left + r.width - 104, r.top + r.height - 42],
      [r.left + r.width - 136, r.top + r.height - 42],
      [r.left + r.width - 44, r.top + r.height - 72],
      [r.left + r.width - 72, r.top + r.height - 72],
    ];

    for (const [x, y] of points) {
      const before = document.body.innerText;
      const ok = clickAtPoint(x, y, "likely-settings-coordinate");
      if (!ok) continue;

      // We don't rely on text only, but if quality appears after click, this is definitely good.
      const afterText = (document.body.innerText || "").toLowerCase();
      if (afterText.includes("quality") || afterText.includes("1080p") || afterText.includes("720p") || afterText.includes("480p")) {
        setPageDebug({ coordinateSettingsClick: "menu-opened", coordinateX: Math.round(x), coordinateY: Math.round(y) });
        return true;
      }
    }

    setPageDebug({ coordinateSettingsClick: "tried-points" });
    return true;
  }

  async function openQualityMenuStrong() {
    revealPlayerControls();
    await sleep(250);

    // If quality options are already visible, no need to open anything.
    if (findQualityOption()) {
      setPageDebug({ openQualityMenuStrong: "option-already-visible" });
      return true;
    }

    // First try text/DOM based settings button.
    const settings = findSettingsButton();
    if (settings) {
      clickEl(settings, "settings-dom");
      setPageDebug({ lastStep: "clicked-settings-dom", settingsText: textOf(settings).slice(0, 200), settingsRect: rectInfo(settings) });
      await sleep(650);

      if (findQualityOption()) {
        setPageDebug({ openQualityMenuStrong: "option-visible-after-settings" });
        return true;
      }

      const qualityEntry = findQualityMenuEntry();
      if (qualityEntry) {
        clickEl(qualityEntry, "quality-menu-dom");
        setPageDebug({ lastStep: "clicked-quality-menu-dom", qualityMenuText: textOf(qualityEntry).slice(0, 200), qualityMenuRect: rectInfo(qualityEntry) });
        await sleep(650);
        return true;
      }
    }

    // If DOM search fails, click likely player control coordinates.
    clickLikelySettingsByCoordinates();
    await sleep(700);

    if (findQualityOption()) {
      setPageDebug({ openQualityMenuStrong: "option-visible-after-coordinate" });
      return true;
    }

    const qualityEntry2 = findQualityMenuEntry();
    if (qualityEntry2) {
      clickEl(qualityEntry2, "quality-menu-after-coordinate");
      setPageDebug({ lastStep: "clicked-quality-menu-after-coordinate", qualityMenuText: textOf(qualityEntry2).slice(0, 200), qualityMenuRect: rectInfo(qualityEntry2) });
      await sleep(700);
      return true;
    }

    setPageDebug({ openQualityMenuStrong: "failed" });
    return false;
  }


  function findSettingsButton() {
    const direct = findSmallTextElementExact([
      /\bsettings\b/i,
      /\bsetting\b/i,
      /إعداد/i,
      /اعداد/i
    ]);
    if (direct) return clickable(direct);

    const all = deepElements().filter(isVisible);
    const buttons = all.filter(el => {
      const tag = el.tagName?.toLowerCase();
      return tag === "button" || el.getAttribute("role") === "button" || el.onclick;
    });

    const video = getMainVideo();
    if (video) {
      const vr = video.getBoundingClientRect();
      const nearBottomRight = buttons
        .map(el => ({ el, r: el.getBoundingClientRect(), text: textOf(el) }))
        .filter(x => x.r.width > 8 && x.r.height > 8)
        .filter(x => x.r.left > vr.left + vr.width * 0.50 && x.r.top > vr.top + vr.height * 0.50)
        .sort((a, b) => (b.r.left + b.r.top) - (a.r.left + a.r.top));

      setPageDebug({
        candidateButtonsBottomRight: nearBottomRight.slice(0, 8).map(x => ({
          text: x.text.slice(0, 80),
          left: Math.round(x.r.left),
          top: Math.round(x.r.top),
          width: Math.round(x.r.width),
          height: Math.round(x.r.height)
        }))
      });

      if (nearBottomRight.length) return clickable(nearBottomRight[0].el);
    }

    return null;
  }

  function findQualityMenuEntry() {
    return findSmallTextElementExact([
      /^quality$/i,
      /\bquality\b/i,
      /\bvideo quality\b/i,
      /\bresolution\b/i,
      /^جودة$/i,
      /الجودة/i,
      /الدقة/i
    ]);
  }

  function qualityRegexes() {
    const q = String(state.config.preferredQuality || "none").toLowerCase();

    if (q === "none") return [];

    if (q === "auto") {
      return [/^auto$/i, /\bauto\b/i, /تلقائي/i];
    }

    if (q === "highest") {
      return [/1080p60/i, /1080p/i, /936p/i, /720p60/i, /720p/i];
    }

    const m = q.match(/(\d{3,4})/);
    if (!m) return [];

    const h = m[1];

    // 1080p should match 1080p60 too.
    return [
      new RegExp(`^${h}p60$`, "i"),
      new RegExp(`^${h}p$`, "i"),
      new RegExp(`\\b${h}p60\\b`, "i"),
      new RegExp(`\\b${h}p\\b`, "i"),
      new RegExp(`^${h}$`, "i")
    ];
  }

  function findQualityOption() {
    const q = String(state.config.preferredQuality || "none").toLowerCase();

    if (q === "none") return null;

    if (q === "highest") {
      const all = deepElements().filter(isVisible);
      const candidates = [];
      for (const el of all) {
        const t = textOf(el);
        const m = t.match(/\b(\d{3,4})p(?:60)?\b/i);
        if (!m) continue;
        const r = el.getBoundingClientRect();
        const area = r.width * r.height;
        if (area > 50000 || r.width > 600 || r.height > 200) continue;
        candidates.push({ el, h: Number(m[1]), text: t, area, rect: rectInfo(el) });
      }
      candidates.sort((a, b) => b.h - a.h || a.area - b.area);
      setPageDebug({
        visibleQualityTexts: candidates.slice(0, 20).map(c => ({ text: c.text.slice(0, 120), h: c.h, rect: c.rect }))
      });
      return candidates[0]?.el || null;
    }

    const found = findSmallTextElementExact(qualityRegexes());

    // Additional text-node fallback: finds exact text node 1080p60 and uses nearest small parent.
    if (!found) {
      const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
      const regs = qualityRegexes();
      let node;
      const candidates = [];
      while ((node = walker.nextNode())) {
        const txt = String(node.nodeValue || "").trim().toLowerCase();
        if (!txt) continue;
        if (!regs.some(r => r.test(txt))) continue;
        let el = node.parentElement;
        for (let depth = 0; el && depth < 6; depth++, el = el.parentElement) {
          if (!isVisible(el)) continue;
          const r = el.getBoundingClientRect();
          const area = r.width * r.height;
          if (area > 0 && area < 50000 && r.width <= 600 && r.height <= 200) {
            candidates.push({ el, text: textOf(el), area, rect: rectInfo(el) });
            break;
          }
        }
      }
      candidates.sort((a, b) => a.area - b.area);
      setPageDebug({
        textNodeQualityCandidates: candidates.slice(0, 10).map(c => ({ text: c.text.slice(0, 120), rect: c.rect }))
      });
      return candidates[0]?.el || null;
    }

    return found;
  }

  async function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async function attemptQuality() {
    if (state.qualityBusy) return;
    if (state.config.preferredQuality === "none") return;
    if (state.qualityDone) return;

    state.qualityBusy = true;
    state.qualityAttempts += 1;

    setPageDebug({
      preferredQuality: state.config.preferredQuality,
      attempts: state.qualityAttempts,
      lastStep: "start",
      done: false,
      url: location.href,
      videoCount: document.querySelectorAll("video").length
    });

    try {
      revealPlayerControls();
      await sleep(350);

      let directOption = findQualityOption();

      if (directOption) {
        clickEl(directOption, "direct-quality-option-precise");
        state.qualityDone = true;
        setPageDebug({ lastStep: "clicked-direct-quality-option-precise", done: true });
        return;
      }

      await openQualityMenuStrong();

      const option = findQualityOption();
      if (option) {
        clickEl(option, "quality-option-precise");
        state.qualityDone = true;
        setPageDebug({ lastStep: "clicked-quality-option-precise", done: true });
      } else {
        setPageDebug({ lastStep: "quality-option-not-found", done: false });
      }
    } catch (e) {
      setPageDebug({ lastStep: "error", error: String(e) });
    } finally {
      state.qualityBusy = false;
    }
  }

  function stopQualityAutomation() {
    if (state.qualityInterval) clearInterval(state.qualityInterval);
    state.qualityInterval = null;
    if (state.qualityObserver) state.qualityObserver.disconnect();
    state.qualityObserver = null;
    state.qualityBusy = false;
    state.qualityDone = false;
    state.qualityAttempts = 0;
  }

  function startQualityAutomation() {
    stopQualityAutomation();

    if (!state.config.preferredQuality || state.config.preferredQuality === "none") {
      setPageDebug({ preferredQuality: state.config.preferredQuality, lastStep: "quality-disabled" });
      return;
    }

    setPageDebug({
      preferredQuality: state.config.preferredQuality,
      attempts: 0,
      lastStep: "waiting",
      done: false
    });

    const runner = () => {
      if (state.qualityDone || state.qualityAttempts >= 20) {
        if (state.qualityInterval) clearInterval(state.qualityInterval);
        state.qualityInterval = null;
        return;
      }
      attemptQuality();
    };

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", runner, { once: true });
    } else {
      runner();
    }

    state.qualityInterval = setInterval(runner, 2500);

    state.qualityObserver = new MutationObserver(() => {
      if (!state.qualityDone && state.qualityAttempts < 20) {
        setTimeout(attemptQuality, 300);
      }
    });

    function startObs() {
      state.qualityObserver.observe(document.body || document.documentElement, { childList: true, subtree: true });
    }

    if (document.body) startObs();
    else document.addEventListener("DOMContentLoaded", startObs, { once: true });
  }

  function applyAll() {
    resetPlaybackRate();
    applyCss();
    startChatTrimmer();
    startQualityAutomation();
    broadcastConfig();
  }

  loadConfig((config) => {
    inject(config);
    setPageDebug({ extensionLoaded: true, lastStep: "loaded", preferredQuality: config.preferredQuality });
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", applyAll, { once: true });
    else applyAll();
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") return;
    chrome.storage.local.get(DEFAULTS, (config) => {
      const oldQ = state.config.preferredQuality;
      state.config = Object.assign({}, DEFAULTS, config);
      if (oldQ !== state.config.preferredQuality) {
        state.qualityDone = false;
      }
      applyAll();
    });
  });


  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.type !== "KickSmoothViewApplyQualityNow") return;

    state.qualityDone = false;
    state.qualityAttempts = 0;
    attemptQuality();

    sendResponse({ ok: true });
  });


  window.addEventListener("message", (event) => {
    if (event.data && event.data.type === "KickSmoothViewApplyQualityNow") {
      state.qualityDone = false;
      state.qualityAttempts = 0;
      attemptQuality();
    }
  });

  setInterval(resetPlaybackRate, 3000);
})();