const DEFAULTS = {
  mode: "reduce",
  hideEmotes: true,
  hideImages: true,
  disableAnimations: true,
  maxChatNodes: 120,
  preferredQuality: "none",
  qualityEngine: "ui-precise",
  lang: "ar"
};

const RESET_DEFAULTS = {
  mode: "reduce",
  hideEmotes: true,
  hideImages: true,
  disableAnimations: true,
  maxChatNodes: 120,
  preferredQuality: "none",
  qualityEngine: "ui-precise"
};

const TEXT = {
  ar: {
    dir: "rtl",
    htmlLang: "ar",
    langToggle: "English",
    title: "Kick SmoothView",
    subtitle: "تقليل تعليق شات Kick وتثبيت جودة البث المفضلة.",
    statusText: "الإضافة شغالة",
    modeTitle: "الوضع",
    modeOff: "إيقاف",
    modeReduce: "تقليل الضغط - مقترح",
    modeAggressive: "تقليل قوي",
    modeBlock: "حظر شات WebSocket",
    performanceTitle: "الأداء",
    hideEmotesText: "إخفاء الإيموتات",
    hideImagesText: "إخفاء صور الشات",
    disableAnimationsText: "إيقاف الحركات والأنيميشن",
    maxChatNodesText: "أقصى عدد رسائل محفوظة",
    giftWarning: "تنبيه: قد لا تظهر بعض تنبيهات القيفت أو الاشتراكات عند تفعيل إخفاء الإيموتات أو صور الشات.",
    qualityTitle: "جودة البث",
    preferredQualityText: "الجودة المفضلة",
    applyQualityNow: "طبّق الجودة الآن",
    qualityNote: "إذا لم تتغير الجودة مباشرة، حرّك الماوس فوق المشغل ثم اضغط الزر مرة ثانية.",
    toolsTitle: "الأدوات",
    resetSettings: "إعادة ضبط الإعدادات",
    brandTitle: "Level One",
    brandText: "صُنعت خصيصًا لمجتمع Level One ☝🏻",
    brandEmail: "L1kick@sm60a.xyz",
    footerText: "Version 3.0.3",
    saved: "تم الحفظ",
    resetDone: "تمت إعادة الضبط",
    options: {
      none: "لا شيء",
      auto: "تلقائي",
      highest: "أعلى جودة متاحة"
    }
  },
  en: {
    dir: "ltr",
    htmlLang: "en",
    langToggle: "العربية",
    title: "Kick SmoothView",
    subtitle: "Reduce Kick chat lag and apply your preferred stream quality.",
    statusText: "Extension active",
    modeTitle: "Mode",
    modeOff: "Off",
    modeReduce: "Reduce load - recommended",
    modeAggressive: "Aggressive reduce",
    modeBlock: "Block chat WebSocket",
    performanceTitle: "Performance",
    hideEmotesText: "Hide emotes",
    hideImagesText: "Hide chat images",
    disableAnimationsText: "Disable animations",
    maxChatNodesText: "Max chat messages kept",
    giftWarning: "Notice: Some gift or subscription alerts may not appear when Hide emotes or Hide chat images is enabled.",
    qualityTitle: "Stream Quality",
    preferredQualityText: "Preferred quality",
    applyQualityNow: "Apply quality now",
    qualityNote: "If quality does not change immediately, move your mouse over the player and press the button again.",
    toolsTitle: "Tools",
    resetSettings: "Reset settings",
    brandTitle: "Level One",
    brandText: "Made especially for the Level One community ☝🏻",
    brandEmail: "L1kick@sm60a.xyz",
    footerText: "Version 3.0.3",
    saved: "Saved",
    resetDone: "Reset done",
    options: {
      none: "None",
      auto: "Auto",
      highest: "Highest available"
    }
  }
};

function q(sel) { return document.querySelector(sel); }
function qa(sel) { return Array.from(document.querySelectorAll(sel)); }

let saveTimer = null;
let saveFlashTimer = null;

function applyLang(lang) {
  const t = TEXT[lang] || TEXT.ar;

  document.documentElement.lang = t.htmlLang;
  document.documentElement.dir = t.dir;
  document.body.dir = t.dir;

  for (const [id, value] of Object.entries(t)) {
    if (id === "options") continue;
    const el = document.getElementById(id);
    if (el) el.textContent = value;
  }

  const preferred = q("#preferredQuality");
  if (preferred) {
    const noneOpt = preferred.querySelector('option[value="none"]');
    const autoOpt = preferred.querySelector('option[value="auto"]');
    const highOpt = preferred.querySelector('option[value="highest"]');

    if (noneOpt) noneOpt.textContent = t.options.none;
    if (autoOpt) autoOpt.textContent = t.options.auto;
    if (highOpt) highOpt.textContent = t.options.highest;
  }
}

async function load() {
  const config = await chrome.storage.local.get(DEFAULTS);
  applyLang(config.lang || "ar");

  const modeRadio = q(`input[name="mode"][value="${config.mode}"]`);
  if (modeRadio) modeRadio.checked = true;

  q("#hideEmotes").checked = !!config.hideEmotes;
  q("#hideImages").checked = !!config.hideImages;
  q("#disableAnimations").checked = !!config.disableAnimations;
  q("#maxChatNodes").value = config.maxChatNodes;
  q("#preferredQuality").value = config.preferredQuality || "none";

  bindEvents();
}

function showMessage(kind = "saved") {
  const currentLang = document.documentElement.lang === "en" ? "en" : "ar";
  const t = TEXT[currentLang];
  const target = q("#savedText");
  if (!target) return;

  target.textContent = kind === "reset" ? t.resetDone : t.saved;

  if (saveFlashTimer) clearTimeout(saveFlashTimer);
  saveFlashTimer = setTimeout(() => {
    target.textContent = "";
  }, 1200);
}

async function saveSettings() {
  const current = await chrome.storage.local.get(DEFAULTS);

  const configToSave = {
    mode: q('input[name="mode"]:checked')?.value || "reduce",
    hideEmotes: q("#hideEmotes").checked,
    hideImages: q("#hideImages").checked,
    disableAnimations: q("#disableAnimations").checked,
    maxChatNodes: Number(q("#maxChatNodes").value || 120),
    preferredQuality: q("#preferredQuality").value || "none",
    qualityEngine: "ui-precise",
    lang: current.lang || "ar"
  };

  await chrome.storage.local.set(configToSave);
  showMessage("saved");
}

function queueSave() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(saveSettings, 150);
}

async function applyQualityNow() {
  await saveSettings();

  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tabs[0]?.id) {
    await chrome.tabs.sendMessage(tabs[0].id, {
      type: "KickSmoothViewApplyQualityNow"
    }).catch(() => {});
  }

  showMessage("saved");
}

async function resetSettings() {
  const current = await chrome.storage.local.get(DEFAULTS);
  await chrome.storage.local.set({
    ...RESET_DEFAULTS,
    lang: current.lang || "ar"
  });

  const config = await chrome.storage.local.get(DEFAULTS);

  const modeRadio = q(`input[name="mode"][value="${config.mode}"]`);
  if (modeRadio) modeRadio.checked = true;

  q("#hideEmotes").checked = !!config.hideEmotes;
  q("#hideImages").checked = !!config.hideImages;
  q("#disableAnimations").checked = !!config.disableAnimations;
  q("#maxChatNodes").value = config.maxChatNodes;
  q("#preferredQuality").value = config.preferredQuality || "none";

  showMessage("reset");
}

function bindEvents() {
  qa('input[name="mode"]').forEach(el => el.addEventListener("change", queueSave));

  ["#hideEmotes", "#hideImages", "#disableAnimations", "#maxChatNodes", "#preferredQuality"].forEach(sel => {
    const el = q(sel);
    if (!el) return;
    el.addEventListener("change", queueSave);
    el.addEventListener("input", queueSave);
  });

  q("#applyQualityNow").addEventListener("click", applyQualityNow);
  q("#resetSettings").addEventListener("click", resetSettings);

  q("#langToggle").addEventListener("click", async () => {
    const current = await chrome.storage.local.get(DEFAULTS);
    const next = (current.lang || "ar") === "ar" ? "en" : "ar";

    await chrome.storage.local.set({ lang: next });
    applyLang(next);
    showMessage("saved");
  });
}

load();