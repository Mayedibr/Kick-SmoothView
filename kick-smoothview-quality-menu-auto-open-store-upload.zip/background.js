const DEFAULTS = { mode: "reduce" };

function isKickUrl(url) {
  return typeof url === "string" && url.includes("kick.com");
}

async function getMode() {
  const data = await chrome.storage.local.get(DEFAULTS);
  return data.mode || "reduce";
}

async function setBadgeForTab(tab) {
  if (!tab || !tab.id) return;
  const mode = await getMode();

  if (isKickUrl(tab.url) && mode !== "off") {
    await chrome.action.setBadgeText({ tabId: tab.id, text: "ON" });
    await chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: "#16a34a" });
    await chrome.action.setTitle({ tabId: tab.id, title: "Kick SmoothView - Active" });
  } else {
    await chrome.action.setBadgeText({ tabId: tab.id, text: "" });
    await chrome.action.setTitle({ tabId: tab.id, title: "Kick SmoothView" });
  }
}

async function refreshAllBadges() {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) await setBadgeForTab(tab);
}

chrome.runtime.onInstalled.addListener(refreshAllBadges);
chrome.runtime.onStartup.addListener(refreshAllBadges);
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status || changeInfo.url) setBadgeForTab(tab);
});
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  const tab = await chrome.tabs.get(activeInfo.tabId);
  await setBadgeForTab(tab);
});
chrome.storage.onChanged.addListener(refreshAllBadges);