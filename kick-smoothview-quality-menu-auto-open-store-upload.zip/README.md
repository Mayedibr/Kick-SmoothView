# Kick SmoothView

Release UI build.

Features:
- Reduce Kick chat load
- Hide emotes/images
- Disable animations
- Limit old chat messages
- Apply preferred stream quality
- Auto-save settings
- Arabic / English UI
- ON badge while active on Kick

Important notice:
Some gift or subscription alerts may not appear when Hide emotes or Hide chat images is enabled.

Debug:
window.__kickSmoothViewGetQualityStats()


Branding update:
- Added Level One footer banner
- Added community note
- Added contact email: L1kick@sm60a.xyz


## Version 3.0.3 - CSP Fix

Fixed:
- Removed inline script injection from content.js.
- Removed scripting permission.
- Apply Quality Now now uses chrome.tabs.sendMessage instead of chrome.scripting.executeScript.
- Debug stats are written to a hidden DOM div instead of executing inline JavaScript.

This avoids Chrome CSP errors related to inline script execution.


## Version 3.0.3 - Quality Menu Auto Open Fix

Fixed:
- Preferred quality no longer requires the user to manually click the player quality/settings menu first.
- The extension now tries DOM-based settings detection first.
- If that fails, it clicks likely player control coordinates near the bottom-right of the video.
