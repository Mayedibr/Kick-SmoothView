(function () {
  const script = document.currentScript;

  let currentConfig = { mode: "reduce", debug: false };

  try {
    if (script && script.dataset.kickSmoothViewConfig) {
      currentConfig = Object.assign(currentConfig, JSON.parse(script.dataset.kickSmoothViewConfig));
    }
  } catch (e) {}

  const OriginalWebSocket = window.WebSocket;
  if (!OriginalWebSocket) return;

  const sockets = [];

  function isKickChatSocket(url) {
    const u = String(url || "").toLowerCase();
    if (!location.hostname.includes("kick.com")) return false;
    if (u.includes(".m3u8") || u.includes(".ts") || u.includes("hls") || u.includes("video") || u.includes("cdn")) return false;
    return ["pusher", "chat", "chatroom", "websocket", "ws"].some(k => u.includes(k));
  }

  function makeFakeClosedSocket(url) {
    const fake = new EventTarget();
    fake.url = String(url);
    fake.readyState = OriginalWebSocket.CLOSED;
    fake.CONNECTING = OriginalWebSocket.CONNECTING;
    fake.OPEN = OriginalWebSocket.OPEN;
    fake.CLOSING = OriginalWebSocket.CLOSING;
    fake.CLOSED = OriginalWebSocket.CLOSED;
    fake.binaryType = "blob";
    fake.bufferedAmount = 0;
    fake.extensions = "";
    fake.protocol = "";
    fake.close = function () {};
    fake.send = function () {};
    setTimeout(() => {
      const ev = new Event("close");
      ev.code = 1000;
      ev.reason = "Blocked by Kick SmoothView";
      ev.wasClean = true;
      fake.dispatchEvent(ev);
      if (typeof fake.onclose === "function") fake.onclose(ev);
    }, 0);
    return fake;
  }

  function closeExistingChatSockets() {
    for (const item of sockets) {
      try {
        if (item && item.ws && item.ws.readyState === OriginalWebSocket.OPEN && isKickChatSocket(item.url)) {
          item.ws.close(1000, "Blocked by Kick SmoothView");
        }
      } catch (e) {}
    }
  }

  function forceNormalPlayback() {
    try {
      document.querySelectorAll("video").forEach(v => {
        if (v.playbackRate !== 1) v.playbackRate = 1;
      });
    } catch (e) {}
  }

  window.__kickSmoothViewStats = {
    socketsOpened: 0,
    socketsBlocked: 0,
    sockets: [],
    stableMode: true,
    playbackRateForcedToNormal: true
  };

  window.WebSocket = new Proxy(OriginalWebSocket, {
    construct(target, args) {
      const url = args[0];

      if (currentConfig.mode === "block" && isKickChatSocket(url)) {
        window.__kickSmoothViewStats.socketsBlocked++;
        return makeFakeClosedSocket(url);
      }

      const ws = Reflect.construct(target, args);
      sockets.push({ ws, url: String(url) });
      window.__kickSmoothViewStats.socketsOpened++;
      window.__kickSmoothViewStats.sockets.push(String(url));
      return ws;
    }
  });

  Object.defineProperty(window.WebSocket, "name", { value: "WebSocket" });

  window.addEventListener("KickSmoothViewConfig", (event) => {
    try {
      currentConfig = Object.assign({}, currentConfig, event.detail || {});
      forceNormalPlayback();
      if (currentConfig.mode === "block") closeExistingChatSockets();
    } catch (e) {}
  });

  setInterval(forceNormalPlayback, 3000);
})();